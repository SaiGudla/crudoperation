package controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import dal.EmpDAO;
import dal.EmpDAOImp;
import model.Employee;
import model.EmployeeList;

@WebServlet("/employee")
public class EmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public EmployeeServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		EmpDAO dao = new EmpDAOImp();
		Gson gson = new Gson();
		response.setContentType("application/json");
		PrintWriter out = response.getWriter();
		String req_parameter = request.getParameter("action");

		String emp_id = request.getParameter("employee_id");
		if (req_parameter == null) {
			EmployeeList emps = dao.getEmp();
			out.write(gson.toJson(emps));
		} else {
			Employee emp = dao.getEmpByOption(req_parameter, emp_id);
			out.write(gson.toJson(emp));
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Gson gson = new Gson();
		BufferedReader reader = new BufferedReader(new InputStreamReader(request.getInputStream()));
		String json = "";
		if (reader != null) {
			json = reader.readLine();
		}
		Employee employee = gson.fromJson(json, Employee.class);
		new EmpDAOImp().addEmp(employee);
	}

	@Override
	protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		int emp_id = Integer.parseInt(req.getParameter("employee_id"));
		new EmpDAOImp().deleteEmp(emp_id);
	}

	@Override
	protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Gson gson = new Gson();
		BufferedReader reader = new BufferedReader(new InputStreamReader(req.getInputStream()));
		String json = "";
		if (reader != null) {
			json = reader.readLine();
		}
		Employee employee = gson.fromJson(json, Employee.class);

		new EmpDAOImp().updateEmp(employee);
	}
}
