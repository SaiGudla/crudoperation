package dal;

import model.Employee;
import model.EmployeeList;

public interface EmpDAO {

	public void addEmp(Employee employee);

	public EmployeeList getEmp();

	public void deleteEmp(int emp_id);

	public void updateEmp(Employee e);

	public Employee getEmpByOption(String req_parameter, String emp_id);

}
