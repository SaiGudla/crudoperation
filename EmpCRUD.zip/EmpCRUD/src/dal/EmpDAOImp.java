package dal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import dbUtilities.DBConnection;
import model.Employee;
import model.EmployeeList;

public class EmpDAOImp implements EmpDAO {
	public Connection con = DBConnection.getConnection();;
	public ArrayList<Employee> employees;
	PreparedStatement st = null;
	String query;
	ResultSet rs = null;

	public void addEmp(Employee employee) {
		query = "insert into mani_emp values(?,?,?,?);";
		try {
			st = con.prepareStatement(query);
			st.setString(1, employee.getName());
			st.setString(2, employee.getDeptno());
			st.setDouble(3, employee.getSalary());
			st.setDate(4, java.sql.Date.valueOf(employee.getHiredate()));
			st.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public EmployeeList getEmp() {
		EmployeeList emp = new EmployeeList();
		query = "select * from mani_emp;";
		try {
			st = con.prepareStatement(query);
			rs = st.executeQuery();
			while (rs.next()) {
				emp.add(new Employee(rs.getString(1), rs.getString(2), rs.getDouble(3), rs.getString(4), rs.getInt(5)));
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return emp;
	}

	public void deleteEmp(int emp_id) {
		query = "delete from mani_emp where emp_id =?;";
		try {
			st = con.prepareStatement(query);
			st.setInt(1, emp_id);
			st.execute();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void updateEmp(Employee e) {
		query = "update mani_emp set name=? ,deptno=? ,salary=? ,hiredate=? where emp_id=?";

		try {
			st = con.prepareStatement(query);
			st.setString(1, e.getName());
			st.setString(2, e.getDeptno());
			st.setDouble(3, e.getSalary());
			st.setDate(4, java.sql.Date.valueOf(e.getHiredate()));
			st.setInt(5, e.getEmp_id());
			st.executeUpdate();

		} catch (SQLException e1) {
			e1.printStackTrace();
		}
	}

	public Employee getEmpByOption(String req_parameter, String emp_id) {
		Employee emp = null;

		if (req_parameter.equals("first")) {
			query = "SELECT * FROM mani_emp ORDER BY emp_id ASC LIMIT 1";
			try {
				st = con.prepareStatement(query);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else if (req_parameter.equals("last")) {
			query = "SELECT * FROM mani_emp ORDER BY emp_id DESC LIMIT 1";
			try {
				st = con.prepareStatement(query);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} else if (req_parameter.equals("next")) {
			query = "SELECT * FROM mani_emp WHERE emp_id > ? ORDER BY emp_id ASC LIMIT 1";
			try {
				st = con.prepareStatement(query);
				st.setInt(1, Integer.parseInt(emp_id));
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} else if (req_parameter.equals("prev")) {
			query = "SELECT * FROM mani_emp WHERE emp_id < ? ORDER BY emp_id DESC LIMIT 1";
			try {
				st = con.prepareStatement(query);
				st.setInt(1, Integer.parseInt(emp_id));
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		try {
			ResultSet rs = st.executeQuery();
			if (rs.next()) {
				emp = new Employee(rs.getString(1), rs.getString(2), rs.getDouble(3), rs.getString(4), rs.getInt(5));
			}
		} catch (SQLException e) {

			e.printStackTrace();
		}

		return emp;
	}
}
