package model;

public class Employee {
	String name;
	String deptno;
	double salary;
	String hiredate;
	int emp_id;

	public Employee(String name, String deptno, double salary, String hiredate, int emp_id) {
		super();
		this.name = name;
		this.deptno = deptno;
		this.salary = salary;
		this.hiredate = hiredate;
		this.emp_id = emp_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDeptno() {
		return deptno;
	}

	public void setDeptno(String deptno) {
		this.deptno = deptno;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getHiredate() {
		return hiredate;
	}

	public void setHiredate(String hiredate) {
		this.hiredate = hiredate;
	}

	public int getEmp_id() {
		return emp_id;
	}

	public void setEmp_id(int emp_id) {
		this.emp_id = emp_id;
	}

	@Override
	public String toString() {
		return "Employee [name=" + name + ", deptno=" + deptno + ", salary=" + salary + ", hiredate=" + hiredate + "]";
	}
}
