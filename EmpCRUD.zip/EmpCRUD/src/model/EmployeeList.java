package model;

import java.util.ArrayList;

public class EmployeeList extends ArrayList<Employee> {

}
