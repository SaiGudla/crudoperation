package controllers;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import dal.EmployeeDAL;
import models.Employee;
import models.EmployeeList;

@WebServlet("/employee")
public class EmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public EmployeeServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		EmployeeDAL dal = new EmployeeDAL();
		Gson gson = new Gson();
		response.setContentType("application/json");
		PrintWriter out = response.getWriter();
		String req_parameter = request.getParameter("action");

		String emp_id = request.getParameter("employee_id");
		if (req_parameter == null) {
			EmployeeList emps = dal.getEmp();
			out.write(gson.toJson(emps));
		} else {
			Employee emp = dal.getEmpByOption(req_parameter, emp_id);
			out.write(gson.toJson(emp));
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Gson gson = new Gson();
		BufferedReader reader = new BufferedReader(new InputStreamReader(request.getInputStream()));
		String json = "";
		if (reader != null) {
			json = reader.readLine();
		}
		Employee employee = gson.fromJson(json, Employee.class);
		new EmployeeDAL().addEmp(employee);
	}

	@Override
	protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("inside doDelete()....");
		int emp_id = Integer.parseInt(req.getParameter("employee_id"));
		new EmployeeDAL().deleteEmp(emp_id);
	}

	@Override
	protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Gson gson = new Gson();
		BufferedReader reader = new BufferedReader(new InputStreamReader(req.getInputStream()));
		String json = "";
		if (reader != null) {
			json = reader.readLine();
		}
		Employee employee = gson.fromJson(json, Employee.class);

		new EmployeeDAL().updateEmp(employee);
	}
}
