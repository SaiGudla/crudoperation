package dal;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import models.Employee;
import models.EmployeeList;

public class EmployeeDAL {
	public static final String URL = "jdbc:postgresql://192.168.110.48:5432/plf_training";
	public static final String UNAME = "plf_training_admin";
	public static final String PWD = "pff123";
	public Connection con;
	public ArrayList<Employee> employees;
	PreparedStatement st = null;
	String query;
	ResultSet rs = null;

	public EmployeeDAL() {
		con = null;
		try {
			Class.forName("org.postgresql.Driver");
			con = DriverManager.getConnection(URL, UNAME, PWD);
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void addEmp(Employee employee) {
		query = "insert into i210_Employee values(?,?,?,?);";
		try {
			st = con.prepareStatement(query);
			st.setString(1, employee.getName());
			st.setString(2, employee.getDeptno());
			st.setDouble(3, employee.getSalary());
			st.setDate(4, java.sql.Date.valueOf(employee.getHiredate()));
			st.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public EmployeeList getEmp() {
		System.out.println("inside getEMP()...................");
		EmployeeList emp = new EmployeeList();
		query = "select * from i210_Employee;";
		try {
			st = con.prepareStatement(query);
			rs = st.executeQuery();
			while (rs.next()) {
				emp.add(new Employee(rs.getString(1), rs.getString(2), rs.getDouble(3), rs.getString(4), rs.getInt(5)));
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return emp;
	}

	public void deleteEmp(int emp_id) {
		query = "delete from i210_Employee where emp_id =?;";
		try {
			st = con.prepareStatement(query);
			st.setInt(1, emp_id);
			st.execute();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void updateEmp(Employee e) {
		query = "update i210_Employee set name=? ,deptno=? ,salary=? ,hiredate=? where emp_id=?";

		try {
			st = con.prepareStatement(query);
			st.setString(1, e.getName());
			st.setString(2, e.getDeptno());
			st.setDouble(3, e.getSalary());
			st.setDate(4, java.sql.Date.valueOf(e.getHiredate()));
			st.setInt(5, e.getEmp_id());
			st.executeUpdate();
			System.out.println(e);
			System.out.println(e.getEmp_id());

		} catch (SQLException e1) {
			e1.printStackTrace();
		}
	}

	public Employee getEmpByOption(String req_parameter, String emp_id) {
		Employee emp = null;

		if (req_parameter.equals("first")) {
			query = "SELECT * FROM i210_Employee ORDER BY emp_id ASC LIMIT 1";
			try {
				st = con.prepareStatement(query);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else if (req_parameter.equals("last")) {
			query = "SELECT * FROM i210_Employee ORDER BY emp_id DESC LIMIT 1";
			try {
				st = con.prepareStatement(query);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} else if (req_parameter.equals("next")) {
			query = "SELECT * FROM i210_Employee WHERE emp_id > ? ORDER BY emp_id ASC LIMIT 1";
			try {
				st = con.prepareStatement(query);
				st.setInt(1, Integer.parseInt(emp_id));
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} else if (req_parameter.equals("prev")) {
			query = "SELECT * FROM i210_Employee WHERE emp_id < ? ORDER BY emp_id DESC LIMIT 1";
			try {
				st = con.prepareStatement(query);
				st.setInt(1, Integer.parseInt(emp_id));
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		try {
			ResultSet rs = st.executeQuery();
			if (rs.next()) {
				emp = new Employee(rs.getString(1), rs.getString(2), rs.getDouble(3), rs.getString(4), rs.getInt(5));
			}
		} catch (SQLException e) {

			e.printStackTrace();
		}

		return emp;
	}
}
